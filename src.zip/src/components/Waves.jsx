/* .box {
  --mask:
    radial-gradient(34.17px at 50% calc(100% - 37.4px),#000 99%,#0000 101%) calc(50% - 68px) 0/136px 100%,
    radial-gradient(34.17px at 50% calc(100% + 3.4px),#0000 99%,#000 101%) 50% calc(100% - 34px)/136px 100% repeat-x;
  -webkit-mask: var(--mask);
          mask: var(--mask);
} */