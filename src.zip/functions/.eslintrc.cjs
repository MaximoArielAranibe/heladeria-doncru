module.exports = {
  env: {
    node: true,
    es2021: true,
  },
  rules: {
    "no-undef": "off",
  },
};
