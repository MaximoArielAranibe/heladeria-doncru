import AdminOrders from "./AdminOrders";

const Orders = () => {
  return <AdminOrders />;
};

export default Orders;
